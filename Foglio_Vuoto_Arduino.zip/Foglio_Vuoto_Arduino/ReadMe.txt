######################################################

Narbolia, 02/10/2023 - Francesco Spanu

######################################################

GUIDA ALL'INSTALLAZIONE DELLE LIBRERIE SU W10:

Per poter installare le librerie, seguire il seguente
percorso:

C:\Users\Administrator\AppData\Local\Arduino15\packages\
  arduino\hardware

Una volta aperta la cartella "hardware", vi ritroverete
le cartelle di tutte le schede installate nella vostra IDE.

Procedura schede "avr":

Cancellate la cartella "avr" 

Una volta eliminata, selezionate col tasto 
sinistro del mouse la cartella "avr"  
contenuta in questo file e trascinatela nella 
cartella "hardware", da cui è stata 
precedentemente eliminata. 
In alternativa selezionate la cartella 
"avr", copiatela e incollatela
all'interno della cartella "hardware" da cui
avete provveduto a eliminarla. 

Procedura schede "sam":

Dalla cartella "hardware", entrate in:
sam\1.6.12

A questo punto, tra le varie cartelle contenute 
in "1.6.12", vi ritrovate la cartella "cores".
Eliminate la cartella "cores".
Tornate in "Foglio_Vuoto_Arduino", 
entrate nella cartella "sam" e copiate la 
cartella "cores". 
Tornate nella cartella "1.6.12" e incollatela.
Per iniziare ad usare le modifiche, aprire il file
"Foglio_vuoto.ino" contenuto in: 
Foglio_Vuoto_Arduino\Foglio_Vuoto, salvatelo con 
un altro nome e iniziate a programmare.


Prossimamente le modifiche per il resto della
gamma di controllori Arduino.
